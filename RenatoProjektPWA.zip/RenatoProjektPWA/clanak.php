<?php
include 'connect.php';
define('UPLPATH', 'img/');
$id= $_GET["id"];

$query = "SELECT * FROM vijesti WHERE id=$id";
            $result = mysqli_query($dbc, $query);
            $i=0;
            while($row = mysqli_fetch_array($result)) {
            $mainTitle=$row['naslov'];
            $category=$row['kategorija'];
            $about=$row['sazetak'];
            $content=$row['tekst'];
            $slika=$row['slika'];
            }

?>
<!DOCTYPE html>
<head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css" />
        <title><?php echo $mainTitle; ?></title>
</head>
<body>
    <header>
    <nav>
    <section id="main-nav">
              <a id="RPImg">
                <img src="97_normal_1529233648.jpg" alt="RP Logo" />
              </a>
              <a class="main-nav-entry" id="main-nav-home" href="index.php">
                <div>Home</div>
                <div class="nav-line nav-blue"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-news" href="Kategorija.php?kategorija=news">
                <div>Politik</div>
                <div class="nav-line nav-red"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-sport" href="Kategorija.php?kategorija=sport">
                <div>Sport</div>
                <div class="nav-line nav-yellow"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-unos" href="unos.html">
                <div>Unos</div>
                <div class="nav-line nav-yellow"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-sport"  href="administracija.php">
                <div>Administracija</div>
                <div class="nav-line nav-yellow"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-sport"  href="prijava.php">
                <div>Registracija</div>
                <div class="nav-line nav-yellow"></div>
              </a>
            </section>
          </nav>
    </header>
    <main>
        <section>
            <article class="fullwidth">
                <section class="main-information">
                    <h1 class="main-title"><?php echo $mainTitle; ?></h1>
                </section>
                <section class="image">
                    <img src="<?php echo  UPLPATH . $slika; ?>">
                </section>
                <section class="content">
                    <p class="about"><?php echo $about; ?></p>
                    <p class="main-content"><?php echo $content; ?></p>
                </section>
            </article>
        </section>
    </main>
    <footer>
            <section id="bottom">
                <div class="col-12 center">
                <h5>&copy;RP DIGITAL GMBH | ALLE RECHTE VORBEHALTEN.Content Management by InterRed</h5>
    </div>
    </section>    
    </footer> 
</body>