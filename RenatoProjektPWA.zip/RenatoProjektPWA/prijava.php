<?php
include 'connect.php';

$msg="";
if(isset($_POST['ime']) && isset($_POST['prezime']) && isset($_POST['username']) && isset($_POST['pass'])){
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $username = $_POST['username'];
    $lozinka = $_POST['pass'];
    $hashed_password = password_hash($lozinka, CRYPT_BLOWFISH);

    $razina = 0;
    $registriranKorisnik = '';

    $sql = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    } 
    if(mysqli_stmt_num_rows($stmt) > 0){
        $msg='Korisničko ime već postoji!';
    }else{
        $sql = "INSERT INTO korisnik (ime, prezime,korisnicko_ime, lozinka, razina)VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 'ssssd', $ime, $prezime, $username, $hashed_password, $razina);
        mysqli_stmt_execute($stmt);
        $registriranKorisnik = true;
     }
    } 
}
mysqli_close($dbc);
?>

<!DOCTYPE html>
<head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css" />
    </head>
    <body>
        <header>
        <nav>
        <section id="main-nav">
            <a id="RPImg">
              <img src="97_normal_1529233648.jpg" alt="RP Logo" />
            </a>
              <a class="main-nav-entry" id="main-nav-home" href="index.php">
                <div>Home</div>
                <div class="nav-line nav-blue"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-news" href="Kategorija.php?kategorija=news">
                <div>Politik</div>
                <div class="nav-line nav-red"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-sport" href="Kategorija.php?kategorija=sport">
                <div>Sport</div>
                <div class="nav-line nav-yellow"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-unos" href="unos.html">
                <div>Unos</div>
                <div class="nav-line nav-yellow"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-sport"  href="administracija.php">
                <div>Administracija</div>
                <div class="nav-line nav-yellow"></div>
              </a>
              <a class="main-nav-entry" id="main-nav-sport"  href="prijava.php">
                <div>Registracija</div>
                <div class="nav-line nav-yellow"></div>
              </a>
            </section>
          </nav>
    <main>
        <form enctype="multipart/form-data" action="" method="POST">
             <div class="form-item">
                <span id="porukaIme" class="error"></span>
                <label for="title">First name: </label>
                <div class="form-field"> 
                    <input type="text" name="ime" id="ime" class="form-field-text"> 
                </div>
             </div>

            <div class="form-item"> 
                <span id="porukaPrezime" class="error"></span>
                <label for="about">Last name: </label>
                <div class="form-field"> 
                    <input type="text" name="prezime" id="prezime" class="form-field-text"> 
                </div> 
            </div> 

            <div class="form-item"> 
                <span id="porukaUsername" class="error"></span> 
                <label for="content">Username:</label>
                <?php echo '<br><span class="error">'.$msg.'</span>'; ?>
                <div class="form-field">
                     <input type="text" name="username" id="username" class="form-field-text">
                </div> 
            </div> 

            <div class="form-item"> 
                <span id="porukaPass" class="error"></span> 
                <label for="pphoto">Password: </label> 
                <div class="form-field">
                    <input type="password" name="pass" id="pass" class="form-field-text"> 
                </div> 
            </div> 
            
            <div class="form-item"> 
                <span id="porukaPassRep" class="error"></span> 
                <label for="pphoto">Repeat password: </label> 
                <div class="form-field"> 
                    <input type="password" name="passRep" id="passRep" class="form-field-text"> 
                </div> 
            </div> 

            <div class="form-item"> 
                <button type="submit" value="submit" id="submit">Register</button>
            </div> 
        </form> 
    </main>
    <script type="text/javascript">
    document.getElementById("submit").onclick = function(event) {
        var slanjeForme = true;
        var poljeIme = document.getElementById("ime");
        var ime = document.getElementById("ime").value;
        if (ime.length == 0) {
            slanjeForme = false;
            poljeIme.style.border="1px dashed red";
            document.getElementById("porukaIme").innerHTML="<br>Enter first name!<br>";
         } else {
            poljeIme.style.border="1px solid green";
            document.getElementById("porukaIme").innerHTML="";
         } 

        var poljePrezime = document.getElementById("prezime");
        var prezime = document.getElementById("prezime").value;
        if (prezime.length == 0) { slanjeForme = false;
            poljePrezime.style.border="1px dashed red"; 
            document.getElementById("porukaPrezime").innerHTML="<br>Enter last name!<br>"; 
        } else {
            poljePrezime.style.border="1px solid green";
            document.getElementById("porukaPrezime").innerHTML="";
         }

        var poljeUsername = document.getElementById("username");
        var username = document.getElementById("username").value;
        if (username.length == 0) {
            slanjeForme = false;
            poljeUsername.style.border="1px dashed red";
            document.getElementById("porukaUsername").innerHTML="<br>Enter username!<br>";
         } else { poljeUsername.style.border="1px solid green";
            document.getElementById("porukaUsername").innerHTML="";
         }
         
        var poljePass = document.getElementById("pass");
        var pass = document.getElementById("pass").value; 
        var poljePassRep = document.getElementById("passRep"); 
        var passRep = document.getElementById("passRep").value; 
        if (pass.length == 0 || passRep.length == 0 || pass != passRep) { 
            slanjeForme = false; 
            poljePass.style.border="1px dashed red"; 
            poljePassRep.style.border="1px dashed red"; 
            document.getElementById("porukaPass").innerHTML="<br>Passwords are not matching!<br>"; 
            document.getElementById("porukaPassRep").innerHTML="<br>Passwords are not matching!<br>"; 
        } else { poljePass.style.border="1px solid green"; 
            poljePassRep.style.border="1px solid green"; 
            document.getElementById("porukaPass").innerHTML=""; 
            document.getElementById("porukaPassRep").innerHTML=""; 
        } if (slanjeForme != true) {
             event.preventDefault(); 
            }
        };
    </script>
   <footer>
            <section id="bottom">
                <div class="col-12 center">
                <h5>&copy;RP DIGITAL GMBH | ALLE RECHTE VORBEHALTEN.Content Management by InterRed</h5>
    </div>
    </section>    
    </footer>
</body>